import { combineReducers } from 'redux';

const allReducers = combineReducers({

});

export default allReducers;