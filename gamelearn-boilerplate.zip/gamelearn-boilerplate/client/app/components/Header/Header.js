import React from 'react';

const Header = () => (
  <header>
  </header>
);

export default Header;
