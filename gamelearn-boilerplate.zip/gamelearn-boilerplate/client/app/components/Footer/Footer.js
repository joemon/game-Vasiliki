import React from 'react';

const Footer = () => (
  <footer>
    
  </footer>
);

export default Footer;
